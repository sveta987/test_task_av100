<template>
  <svg content="Лента будет автоматически обновляться 1 раз в 3 секунды"
       xmlns="http://www.w3.org/2000/svg" class="checkbox-label__tooltip-icon icon sprite-icons"
       tabindex="0">
    <use href="/_nuxt/32e24a6feae9c4f24ba1be74b5843912.svg#i-i-hint"
         xlink:href="/_nuxt/32e24a6feae9c4f24ba1be74b5843912.svg#i-i-hint">

    </use>
  </svg>
</template>

<script>
export default {
  name: "Question"
}
</script>

<style scoped>

</style>
