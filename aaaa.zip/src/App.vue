<template>
  <form action="" class="m-[20px]">
    <div class=" sip flex flex-row">
      <h3 class="subheading">Звонок через SIP</h3>
      <label class="inline-flex relative  mr-5 cursor-pointer">
        <input type="checkbox" value="" class="sr-only peer" checked>
        <div
          class="w-11 h-6 bg-white rounded-full peer peer-checked:after:translate-x-full after:content-[''] after:absolute after:top-0.5 after:left-[2px] border-[1px] after:border-gray-500 border-gray-500 peer-checked:border peer-checked:border-green-600 peer-checked:after:bg-green-600 after:border peer-checked:after:border-green-600 after:rounded-full after:h-5 after:w-5 after:transition-all peer"></div>
      </label>
      <p class="ml-3 text-sm text-gray-400 ">Включите эту функцию чтобы Авито и другие площадки не <br/> блокировали ваш
        аккаунт. Будет выглядеть так, будто звонки ,<br/> совершаются с разных номеров.</p>
    </div>

    <div class="account flex flex-row mt-[30px]">
      <h3 class="subheading">Учётная запись</h3>
      <div class="ml-[90px] text-sm">
        <div class="mb-[10px]">
          <label for="company">Компания</label>
          <input type="text" id="company" class="inputStyle ml-[10px]">
        </div>
        <div class="mb-[10px]">
          <label for="login">Логин</label>
          <input type="text" id="login" class="inputStyle ml-[36px]">
        </div>
        <div class="mb-[10px]">
          <label for="phone">Номер <br/> телефона</label>
          <input type="text" id="phone" class="inputStyle ml-[15px]">
        </div>
        <div class="mb-[10px]">
          <label for="name">Имя</label>
          <input type="text" id="name" class="inputStyle ml-[48px]">
        </div>
        <div class="mb-[10px]">
          <label for="surname">Фамилия</label>
          <input type="text" id="surname" class="inputStyle ml-[17px]">
          <p class="text-gray-400 text-[10px] flex justify-center">* Не обязательно</p>
        </div>

      </div>
    </div>

    <div class="notification flex flex-row mt-[40px]">
      <h3 class="subheading">Оповещения о новых <br/> подборках</h3>
      <div class="ml-[35px] ">
        <p class=" text-sm text-gray-400 ">Выберите, куда будут приходить уведомления при появлении <br/> автомобилей,
          которые подходят под критерии вашей подборки.</p>
        <h5 class="my-[25px] font-bold text-[15px]">Уведомления</h5>
        <div class="flex flex-col">
          <div class="py-[15px]">
            <input type="radio" :id="'off'" :name="'off'" v-model="notification"
                   :value="'off'"
                   class="accent-green-600 h-[15px] w-[20px]">
            <label :for="'for'" class=" ">
              Выкл
            </label>
          </div>

          <div class="border-y-[1px] py-[15px] flex justify-between">
            <div>
              <input type="radio" :id="'email'" :name="'email'" v-model="notification"
                     :value="'email'"
                     class="accent-green-600 h-[15px] w-[20px]">
              <label :for="'email'" class=" ">
                Email
              </label>
            </div>
            <div>
              <pencil
                v-show="!isOpenInput.inputNames.includes('email')"
                class="cursor-pointer"
                @click="openInput('email')"
              />
              <input v-show="isOpenInput.inputNames.includes('email')" type="text"  class="inputStyle !my-[0px]">

            </div>

          </div>

          <div class="py-[15px] flex justify-between">
            <div>
              <input type="radio" :id="'telegram'" :name="'telegram'" v-model="notification"
                     :value="'telegram'"
                     class="accent-green-600 h-[15px] w-[20px]">
              <label :for="'telegram'" class=" ">
                Telegram ID
              </label>
            </div>
            <div>
              <pencil
                v-show="!isOpenInput.inputNames.includes('telegram')"
                class="cursor-pointer"
                @click="openInput('telegram')"
              />
              <input v-show="isOpenInput.inputNames.includes('telegram')" type="text"  class="inputStyle !my-[0px]">
            </div>

          </div>

        </div>
      </div>
    </div>

    <div class="restSettings flex flex-row mt-[30px] ">
      <h3 class="subheading">Прочие настройки</h3>
      <div class="flex flex-col">
        <div class="ml-[60px]">
          <label for="cities">Часовой пояс</label>
          <select id="cities" class="inputStyle ml-[45px] !mt-[0px] !px-[30px] !hover:border-green-600">
            <option value="Kaliningrad" class="bg-green-600 ">Калининград</option>
            <option value="Moscow" class="bg-green-600">Москва</option>
            <option value="Samara" class="bg-green-600">Самара</option>
            <option value="Yekaterinburg" class="bg-green-600">Екатеринбург</option>
            <option value="Omsk" class="bg-green-600">Омск</option>
            <option value="Krasnoyarsk" class="bg-green-600">Красноярск</option>
            <option value="Irkutsk" class="bg-green-600">Иркутск</option>
            <option value="Yakutsk" class="bg-green-600">Якутск</option>
            <option value="Vladivostok" class="bg-green-600">Владивосток</option>
            <option value="Magadan" class="bg-green-600">Магадан</option>
            <option value="Kamchatka" class="bg-green-600">Камчатка</option>
          </select>
        </div>
        <div class="autoUpdate mt-[30px] ml-[60px] flex justify-between">
          <div>
            <input type="checkbox" v-model="autoUpdate" id="autoUpdate">
            <label for="autoUpdate" class="text-[10px] align-middle">
              Автоматически переходить к новым объявлениям
            </label>
          </div>
          <ExclamationCircleIcon  class="w-[17px] h-[17px]"/>
        </div>
      </div>
      </div>
  </form>
</template>

<script>
import Pencil from "@/components/Pencil";
import { ExclamationCircleIcon } from '@heroicons/vue/24/outline';

export default {
  name: 'App',
  components:{
    ExclamationCircleIcon,
    Pencil
  },
  data() {
    return {
      notification: 'off',
      autoUpdate: false,
      isOpenInput: {
        inputNames: [],
        isOpen: false,
      }
    }
  },
  methods:{
    openInput (value) {
      this.isOpenInput.inputNames.push(value);
      this.isOpenInput.isOpen = true;
    }
  }
}
</script>

<style>
select:focus > option:checked {
  background: darkgreen !important;
  padding: 3px 0;
}
select:focus > option:active::after{
  outline: none;
  background: darkgreen !important;
}
</style>
